#!/usr/bin/ruby
system("java -jar submit.jar")
